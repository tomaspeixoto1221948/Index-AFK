# Index-AFK

## Features:

- **Automatic Entry and Exit:**
  - Seamlessly enter and exit mission automatically.
  - Rejoin mission effortlessly.
  - Quit from the mission and rejoin it if your Warframe dies.

- **AFK Prevention:**
  - Prevent being marked as AFK during gameplay.
  - Automatically transfer back to the operator upon the Warframe's death

    
